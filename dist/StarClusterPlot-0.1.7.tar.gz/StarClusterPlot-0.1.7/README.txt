This is a Python library for visualizing star clusters and their Hertzsprung-Russell diagrams. 
All stars colors shown in this program are derived from their calculated temperatures.
The package includes two functions: ClusterVis() and HRDiagram().